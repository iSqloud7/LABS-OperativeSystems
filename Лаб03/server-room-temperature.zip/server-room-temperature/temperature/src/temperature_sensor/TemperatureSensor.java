//package temperature_sensor;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class TemperatureSensor {
    public static void main(String[] args)
    {
        try{
            while (true){
                int temperature=generateRandomTemperature();
                writeTemperatureToFile(temperature);
                Thread.sleep(3000);
            }
        } catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    private static int generateRandomTemperature(){
        Random random=new Random();
        return random.nextInt(46) + 5;
    }

    private static void writeTemperatureToFile(int temperature){
        try {
            FileWriter writer=new FileWriter("temperature.txt", true);
            writer.write(temperature + " \n");
            writer.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}