//package temperature_monitor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TemperatureMonitor {

    public static void main(String[] args) {
        try {
            while (true) {
                int averageTemperature = calculateAverageTemperature();
                String temperatureLevel = calculateTemperatureLevel(averageTemperature);
                writeTemperatureLevelToFile(temperatureLevel);
                Thread.sleep(60000); // Sleep for 60 seconds
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static int calculateAverageTemperature() {
        int sum = 0;
        int count = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader("temperature.txt"));
            String line = reader.readLine();
            while (line != null) {
                String[] temperatures = line.trim().split(" ");
                for (String temp : temperatures) {
                    sum += Integer.parseInt(temp);
                    count++;
                }
                line = reader.readLine();
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return count == 0 ? 0 : sum / count;
    }

    private static String calculateTemperatureLevel(int averageTemperature) {
        if (averageTemperature >= 5 && averageTemperature <= 19) {
            return "Low";
        } else if (averageTemperature >= 20 && averageTemperature <= 35) {
            return "Medium";
        } else {
            return "High";
        }
    }

    private static void writeTemperatureLevelToFile(String temperatureLevel) {
        try {
            FileWriter writer = new FileWriter("temperaturelevel.txt");
            writer.write(temperatureLevel + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}